﻿namespace Compra_Vehiculo
{
    partial class Detalle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Detalle));
            this.btnComprar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Marca = new System.Windows.Forms.Label();
            this.Modelo = new System.Windows.Forms.Label();
            this.kmh = new System.Windows.Forms.Label();
            this.Color = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TipoA = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Combustible = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Anio = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnComprar
            // 
            this.btnComprar.Location = new System.Drawing.Point(335, 273);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(81, 29);
            this.btnComprar.TabIndex = 0;
            this.btnComprar.Text = "COMPRAR";
            this.btnComprar.UseVisualStyleBackColor = true;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Marca";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Modelo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "km/h:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Color";
            // 
            // Marca
            // 
            this.Marca.AutoSize = true;
            this.Marca.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Marca.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Marca.Location = new System.Drawing.Point(155, 22);
            this.Marca.Name = "Marca";
            this.Marca.Size = new System.Drawing.Size(0, 18);
            this.Marca.TabIndex = 5;
            // 
            // Modelo
            // 
            this.Modelo.AutoSize = true;
            this.Modelo.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Modelo.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Modelo.Location = new System.Drawing.Point(154, 54);
            this.Modelo.Name = "Modelo";
            this.Modelo.Size = new System.Drawing.Size(0, 18);
            this.Modelo.TabIndex = 6;
            // 
            // kmh
            // 
            this.kmh.AutoSize = true;
            this.kmh.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kmh.ForeColor = System.Drawing.SystemColors.Highlight;
            this.kmh.Location = new System.Drawing.Point(156, 86);
            this.kmh.Name = "kmh";
            this.kmh.Size = new System.Drawing.Size(69, 18);
            this.kmh.TabIndex = 7;
            this.kmh.Text = "00,00km/h";
            // 
            // Color
            // 
            this.Color.AutoSize = true;
            this.Color.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Color.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Color.Location = new System.Drawing.Point(154, 121);
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(0, 18);
            this.Color.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 40);
            this.label5.TabIndex = 4;
            this.label5.Text = "Tipo de Vehiculo:";
            // 
            // TipoA
            // 
            this.TipoA.AutoSize = true;
            this.TipoA.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TipoA.ForeColor = System.Drawing.SystemColors.Highlight;
            this.TipoA.Location = new System.Drawing.Point(154, 172);
            this.TipoA.Name = "TipoA";
            this.TipoA.Size = new System.Drawing.Size(0, 18);
            this.TipoA.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 18);
            this.label6.TabIndex = 4;
            this.label6.Text = "Combustible:";
            // 
            // Combustible
            // 
            this.Combustible.AutoSize = true;
            this.Combustible.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Combustible.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Combustible.Location = new System.Drawing.Point(154, 212);
            this.Combustible.Name = "Combustible";
            this.Combustible.Size = new System.Drawing.Size(0, 18);
            this.Combustible.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 18);
            this.label7.TabIndex = 4;
            this.label7.Text = "Año:";
            // 
            // Anio
            // 
            this.Anio.AutoSize = true;
            this.Anio.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Anio.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Anio.Location = new System.Drawing.Point(154, 244);
            this.Anio.Name = "Anio";
            this.Anio.Size = new System.Drawing.Size(0, 18);
            this.Anio.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(261, 273);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 28);
            this.button1.TabIndex = 9;
            this.button1.Text = "Atras";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Detalle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(429, 315);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Anio);
            this.Controls.Add(this.Combustible);
            this.Controls.Add(this.TipoA);
            this.Controls.Add(this.Color);
            this.Controls.Add(this.kmh);
            this.Controls.Add(this.Modelo);
            this.Controls.Add(this.Marca);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnComprar);
            this.Name = "Detalle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalle";
            this.Load += new System.EventHandler(this.Detalle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnComprar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label Marca;
        public System.Windows.Forms.Label Modelo;
        public System.Windows.Forms.Label kmh;
        public System.Windows.Forms.Label Color;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label TipoA;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label Combustible;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label Anio;
        private System.Windows.Forms.Button button1;
    }
}