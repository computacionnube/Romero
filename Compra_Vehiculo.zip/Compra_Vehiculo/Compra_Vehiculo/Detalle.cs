﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Detalle : Form
    {
        public Detalle()
        {
            InitializeComponent();
        }
     
        private void btnComprar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Formulario F = new Formulario();       
            F.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Detalle_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
