﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Efectivo : Form
    {
        public Efectivo()
        {
            InitializeComponent();
        }
        public string efect;
        public void efectivo()
        {
            efect = txtMonto.Text;
        }


        private void txtMonto_KeyPress(object sender, KeyPressEventArgs e)
        {
            char pre = e.KeyChar;
            if (!char.IsNumber(pre) && pre != 13 && pre != 8 && pre != 32 && pre != 36 && pre != 44)
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtMonto.TextLength == 0)
            {
                MessageBox.Show("Forma de pago vacio por favor complete", "Mensaje");
            }
            else
            {
                this.Hide();
                efectivo();
            }
        }
    }
}
