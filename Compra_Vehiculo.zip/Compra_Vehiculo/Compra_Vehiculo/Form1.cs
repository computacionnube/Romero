﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // this.Hide();
            Iniciar Star = new Iniciar();
            Star.Show();
        }

        private void timer_Tick(object sender, EventArgs e)
        {

            pgbAcceder.Increment(1);
            lblTiemp.Text = pgbAcceder.Value.ToString() + "%";
            btnIniciar.Visible = false;
            btnExit.Visible = true;
            if (pgbAcceder.Value == pgbAcceder.Maximum)
                {
                    timer.Stop();
                    this.Hide();
                    Menu Main = new Menu();
                    Main.Show();
                    
                }
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
