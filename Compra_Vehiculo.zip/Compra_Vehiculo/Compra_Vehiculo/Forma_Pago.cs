﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Forma_Pago : Form
    {

        public Forma_Pago()
        {
            InitializeComponent();
        }
  
        public string tarjt, costo, Npagom;
        public void LLenaP()
        {

           tarjt = txtTarjeta.Text;
            costo = txtCosto.Text;
            Npagom = txtNumeroPa.Text;
            
  
        }
       
        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtTarjeta.TextLength == 0 || txtCosto.TextLength == 0 || txtNumeroPa.TextLength == 0)
            {
                MessageBox.Show("Datos incompletos termine de llenar");
            }
            else
            {
                this.Hide();
                LLenaP();
            }
            
        }

        private void txtTarjeta_KeyPress(object sender, KeyPressEventArgs e)
        {
            char nu = e.KeyChar;
            if (!char.IsNumber(nu) && nu != 13 && nu != 8 && nu != 32)
            {
                e.Handled = true;
            }
        }

        private void txtCosto_KeyPress(object sender, KeyPressEventArgs e)
        {
            char pre = e.KeyChar;
            if (!char.IsNumber(pre) && pre != 13 && pre != 8 && pre != 32 && pre != 36 && pre != 44)
            {

                e.Handled = true;

            }
        }

        private void txtNumeroPa_KeyPress(object sender, KeyPressEventArgs e)
        {
            char nu = e.KeyChar;
            if (!char.IsNumber(nu) && nu != 13 && nu != 8 && nu != 32)
            {
                e.Handled = true;
            }
        }

   
    }
}
