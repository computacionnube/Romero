﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Formulario : Form
    {
       
        public Formulario()
        {
            InitializeComponent();
           
        }
        Resultados Re = new Resultados();
        Forma_Pago Credito = new Forma_Pago();
        Efectivo Efectivos = new Efectivo();
        int i=1;
        string cedula, nombre, apellido, direccion, telefono, referencia, credit;
       public void llenar()
        {
           
           
            cedula = txtCedula.Text;
            nombre = txtNombre.Text;
            apellido = txtApellido.Text;
            direccion = txtDireccion.Text;
            telefono = txtTelefono.Text;
            referencia = txtRefer.Text;
            credit = cboCredito.Text;
          // Re.dgvResult.Rows.Add(i, cedula, nombre, apellido, direccion, telefono, referencia,credit);
         // Re.Show();

        }
      
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtCedula.TextLength == 0 || txtNombre.TextLength == 0 || txtApellido.TextLength == 0 || txtDireccion.TextLength == 0 || txtTelefono.TextLength == 0 || txtRefer.TextLength == 0 || cboCredito.TabIndex == 0)
            {
                MessageBox.Show("El Formulario esta incompleto termine de completar","Mensaje");
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Seguro que desea guardar la informacion", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    this.Hide();
                    llenar();
                    if (cboCredito.SelectedIndex == 0)
                    {
                        Efectivos.efectivo();
                        Re.lstPagos.Items.Add("---------------REGISTRO DE PAGOS----------------");
                        Re.lstPagos.Items.Add("El monto que ha pagado es de: " + Efectivos.efect);
                    }
                    else
                        if (cboCredito.SelectedIndex == 1)
                        {
                            Credito.LLenaP();
                            Re.lstPagos.Items.Add("--------------REGISTRO DE PAGOS----------------");
                            Re.lstPagos.Items.Add("El numero de tarjeta es: " + Credito.tarjt +  "\t El valor del auto es de: " + Credito.costo + "\t los meses de credito son de: " + Credito.Npagom);
                        }

                    Re.dgvResult.Rows.Add(i, cedula, nombre, apellido, direccion, telefono, referencia, credit);
                    Re.Show();
                }
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            //Resultados Res = new Resultados();
            Re.dgvResult[1, Re.pos].Value = txtCedula.Text;
            Re.dgvResult[2, Re.pos].Value = txtNombre.Text;
            Re.dgvResult[3, Re.pos].Value = txtApellido.Text;
            Re.dgvResult[4, Re.pos].Value = txtDireccion.Text;
            Re.dgvResult[5, Re.pos].Value = txtTelefono.Text;
            Re.dgvResult[6, Re.pos].Value = txtRefer.Text;
            Re.Show();
        }

        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            char nu = e.KeyChar;
            if (!char.IsNumber(nu) && nu != 13 && nu != 8 && nu != 32)
            {
                e.Handled = true;
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            char nu = e.KeyChar;
            if (!char.IsNumber(nu) && nu != 13 && nu != 8 && nu != 32)
            {
                e.Handled = true;
            }
        }

        private void txtRefer_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void cboCredito_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCredito.SelectedIndex==0)
            {
                Efectivos.Show();
                cboCredito.Enabled = false;
            }
            else
                if (cboCredito.SelectedIndex==1)
                {
                    Credito.Show();
                    cboCredito.Enabled = false;
                }
        }
    }
}
