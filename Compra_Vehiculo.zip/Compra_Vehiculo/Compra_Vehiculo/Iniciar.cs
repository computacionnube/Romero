﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Iniciar : Form
    {
        public Iniciar()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char contra = e.KeyChar;
            if (!char.IsNumber(contra) && contra != 8 && contra != 32)
            {

                e.Handled = true;

            }
            if (txtCont.TextLength > 0)
            {
                txtCont.PasswordChar = '*';
            if (contra == 13)//
            {                  
                        if (txtCont.Text == "1234")
                        {
                            btnAceptar.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("Contraseña Incorrecta", "Verificación");
                            txtCont.Clear();
                        }
                    }
                  
              
            }
          
        }
      

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();          
            frm.timer.Start();           
            frm.Show();
            
        }


        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {

            char Usuario = e.KeyChar;
            if (!char.IsLetter(Usuario) && Usuario != 8 && Usuario != 32)
            {
                e.Handled = true;
            }
            if (Usuario==13)
            {
                if (txtUsu.Text == "VACIO")
                {
                    txtCont.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Usuario no Autorizado", "Verificación");
                    txtUsu.Text = "";
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
