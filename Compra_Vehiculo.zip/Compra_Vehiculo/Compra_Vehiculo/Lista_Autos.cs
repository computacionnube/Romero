﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Lista_Autos : Form
    {
       
        public Lista_Autos()
        {
            InitializeComponent();
        }
        Detalle det = new Detalle();
        public string marcas, modelos, km, color;

        private void pct3_Click(object sender, EventArgs e)
        { if (pct3.Capture == true)
            {
                //Detalle det3 = new Detalle();
         
                marcas =det.Marca.Text= "Chevrolet";
                modelos=det.Modelo.Text = "Luv D-max ";
                det.kmh.Text = "00,00km/h";
                det.Color.Text = "Dorado";
                det.TipoA.Text = "Dob/cab 4x2 T/m";
                det.Combustible.Text = "Diesel";
                det.Anio.Text = "2017";
               det.Show();
            }

        }

        private void pct1_Click(object sender, EventArgs e)
        {
            if (pct1.Capture == true)
            {
                Detalle det1 = new Detalle();
                det1.Marca.Text = "Bmw";
                det1.Modelo.Text = "328 I Sedan";
                det1.kmh.Text = "00,00km/h";
                det1.Color.Text = "Azul";
                det1.TipoA.Text = "Auto";
                det1.Combustible.Text = "Gasolina ";
                det1.Anio.Text = "2013";
                det1.Show();
            }
        }

        private void pct2_Click(object sender, EventArgs e)
        {
            if (pct2.Capture == true)
            {
                Detalle det2 = new Detalle();
                det2.Marca.Text = "Volkswagen";
                det2.Modelo.Text = "New Beetle T/a";
                det2.kmh.Text = "00,00km/h";
                det2.Color.Text = "Negro";
                det2.TipoA.Text = "Auto";
                det2.Combustible.Text = "Gasolina ";
                det2.Anio.Text = "2014";
                det2.Show();
            }
        }

        private void pct4_Click(object sender, EventArgs e)
        {
            if (pct4.Capture == true)
            {
                Detalle det4 = new Detalle();
                det4.Marca.Text = "Chevrolet";
                det4.Modelo.Text = "Trail Blazer T/a 2.8 ";
                det4.kmh.Text = "00,00km/h";
                det4.Color.Text = "Negro";
                det4.TipoA.Text = "Todo Terreno 4x4";
                det4.Combustible.Text = "Diesel  ";
                det4.Anio.Text = "2017";
                det4.Show();
            }
        }

        private void pct5_Click(object sender, EventArgs e)
        {
            if (pct5.Capture == true)
            {
                Detalle det5 = new Detalle();
                det5.Marca.Text = "Toyota";
                det5.Modelo.Text = "Prius Limited Hibrido ";
                det5.kmh.Text = "00,00km/h";
                det5.Color.Text = "Plata";
                det5.TipoA.Text = "Auto";
                det5.Combustible.Text = "Gasolina  ";
                det5.Anio.Text = "2012";
                det5.Show();
            }
        }

        private void pct6_Click(object sender, EventArgs e)
        {

            if (pct6.Capture == true)
            {
                Detalle det6 = new Detalle();
                det6.Marca.Text = "Toyota";
                det6.Modelo.Text = "Hilux 4x2 ";
                det6.kmh.Text = "00,00km/h";
                det6.Color.Text = "Plata";
                det6.TipoA.Text = "Dob/cab";
                det6.Combustible.Text = " Diesel  ";
                det6.Anio.Text = "2012";
                det6.Show();
            }
        }

     
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
