﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }


        private void listaDeAutosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            Lista_Autos Lista = new Lista_Autos();
            Lista.Show();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
           
        }

        private void vENDERVEHÍCULOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Venta_Vehiculo venta = new Venta_Vehiculo();
            venta.Show();
        }
    }
}
