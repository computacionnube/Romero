﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    
    public partial class Resultados : Form
    {
        public Resultados()
        {
            InitializeComponent();
        }
        public int  pos ;
       
        private void dgvResult_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            this.Hide();
            pos = dgvResult.CurrentRow.Index;
            Formulario For = new Formulario();
            For.txtCedula.Text = dgvResult[1, pos].Value.ToString();
            For.txtNombre.Text = dgvResult[2, pos].Value.ToString();
            For.txtApellido.Text = dgvResult[3, pos].Value.ToString();
            For.txtDireccion.Text = dgvResult[4, pos].Value.ToString();
            For.txtTelefono.Text = dgvResult[5, pos].Value.ToString();
            For.txtRefer.Text = dgvResult[6, pos].Value.ToString();
          
           For.Show();
            this.Hide();
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
