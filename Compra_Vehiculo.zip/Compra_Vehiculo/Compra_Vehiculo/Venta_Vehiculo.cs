﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_Vehiculo
{
    public partial class Venta_Vehiculo : Form
    {
        public Venta_Vehiculo()
        {
            InitializeComponent();
        }

        private void llenar()
        {
            string prop,marca,modelo,anio,motor,color,tip_A,chasis,precio,placa;
            prop = txtProp.Text;
            marca = txtMarca.Text;
            modelo = txtModelo.Text;
            anio = txtAn.Text;
            motor = txtMotor.Text;
            color = txtColor.Text;
            tip_A = txtTipA.Text;
            chasis = txtChasis.Text;
            placa=txtPlaca.Text;
            precio = txtPrecio.Text;
            Venta Ve = new Venta();
            Ve.dgvVenta.Rows.Add(prop, marca, modelo, anio, motor, color, tip_A, chasis, placa,precio);
            Ve.Show();

        }
        private void limpiar()
        {
            txtProp.Clear();
            txtMarca.Clear();
            txtModelo.Clear();
            txtAn.Clear();
            txtMotor.Clear();
            txtColor.Clear();
            txtTipA.Clear();
            txtChasis.Clear();
            txtPrecio.Clear();
            txtPlaca.Clear();
        }

        private void txtProp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char Pro = e.KeyChar;
            if (!char.IsLetter(Pro)&&Pro !=13 && Pro != 8 && Pro != 32)
            {
                e.Handled = true;
            }
        }

        private void txtMarca_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtModelo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtAn_KeyPress(object sender, KeyPressEventArgs e)
        {
            char anio = e.KeyChar;
            if (!char.IsNumber(anio) && anio != 13 && anio != 8 && anio != 32)
            {

                e.Handled = true;

            }
        }

        private void txtMotor_KeyPress(object sender, KeyPressEventArgs e)
        {
           /* char motor = e.KeyChar;
            if (!char.IsNumber(motor) && motor != 13 && motor != 8 && motor != 32)
            {

                e.Handled = true;

            }*/
        }

        private void txtColor_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtTipA_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetter(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtChasis_KeyPress(object sender, KeyPressEventArgs e)
        {
            char let = e.KeyChar;
            if (!char.IsLetterOrDigit(let) && let != 13 && let != 8 && let != 32)
            {
                e.Handled = true;
            }
        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            char pre = e.KeyChar;
            if (!char.IsNumber(pre) && pre != 13 && pre != 8 && pre != 32 && pre!=36 && pre!=44)
            {

                e.Handled = true;

            }
        }

        private void btnAuto_Click(object sender, EventArgs e)
        {
            OpenFileDialog Imagen = new OpenFileDialog();
            Imagen.InitialDirectory = "C:\\";
            Imagen.Filter = "Archivos de imagen (*.jpg)(jpeg)|*.jpg;*.jpeg|PNG(*.png)|*.png";
            if (Imagen.ShowDialog() == DialogResult.OK)
            {
                SelectI.ImageLocation = Imagen.FileName;

            }
            else
            {
                MessageBox.Show("No tiene ninguna imagen seleccionada seguro que desea salir", "Mensaje", MessageBoxButtons.OK);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            
                if (txtProp.TextLength==0||txtMarca.TextLength==0||txtModelo.TextLength==0||txtAn.TextLength==0||txtMotor.TextLength==0||txtMarca.TextLength==0
                    || txtTipA.TextLength==0||txtChasis.TextLength==0||txtPrecio.TextLength==0||txtPlaca.TextLength==0)
                {
                    MessageBox.Show("Formulario vacio por favor complete los datos");   
                }
                else
                if (DialogResult.Yes == MessageBox.Show("Auto vendido!!", "Venta"))
                {
                    llenar();
                }
            
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {

            if (DialogResult.Yes == MessageBox.Show("Esta seguro que desea Borrar la información", "Borrar", MessageBoxButtons.YesNo, MessageBoxIcon.Stop))
            {
                limpiar();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            if (DialogResult.Yes == MessageBox.Show("Esta seguro que dese salir", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation))
            {
                this.Close();
            }
        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
